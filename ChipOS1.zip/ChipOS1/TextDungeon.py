import random
import time
import math
print ("*|TEXT DUNGEON|*")
time.sleep(1)
print ("1. Start")
time.sleep(1)
print ("2. give up :P")
time.sleep(1)
print ("")
menu = int(input("Type the number to select..."))
if menu==1:
  print("you are entering the dungeon...")
elif menu==2:
  print("Game over!")
else:
  print(menu + " is not an option.")
  print("you may restart the game for being foolish")

if menu==1:
  room = 0
  life = 100
  damage = 1
  spawn = 0
  while room<10:
  
    room = random.randrange(0,10)
    if room==1:
      print("")
      print("")
      print("you find a door to the left")
      time.sleep(2)
      print("")
      print("you go through it")
      time.sleep(1)
    elif room==2:
      print("")
      print("")
      print("you find a door to the right")
      time.sleep(2)
      print("")
      print("you go through it")
      time.sleep(1)
    elif room==3:
      print("")
      print("")
      print("you find a door in front of you")
      time.sleep(2)
      print("")
      print("you go through it")
      time.sleep(1)
    elif room==4:
      print("")
      print("")
      print("There are two doors.")
      time.sleep(2)
      print("1. go through the first.")
      print("2. go through the second.")
      way = int(input("Type the number to select..."))
      time.sleep(2)
      print("you go through the selected door")
      time.sleep(1)
    elif room==5:
      print("")
      print("")
      print("There are three doors.")
      time.sleep(2)
      print("1. go through the first.")
      print("2. go through the second.")
      print("3. go through the third.")
      way = int(input("Type the number to select..."))
      time.sleep(2)
      print("you go through the selected door")
      time.sleep(1)
    if room<6:
      spawn = random.randrange(0,6)
      if spawn==2:
        print("You found a better weapon")
        damage = 1 + int(damage)
        print("you now make ", damage, " damage!")
      elif spawn==3:
        print("You found a healing spot")
        if life<100:
          print("you used it to fully heal")
          life = 100
        else:
          print("but you dont need it")
      elif spawn==4:
        print("you walked into a trap")
        life = int(life) - 10
        print("your life is down to ", life)
        if life==0:
          print("Game over!")
          room = 11
      elif spawn==4:
      	enemie = random.randrange(1,10)
      	print("an enemie with " ,enemie," life attacks you")
      	if enemie<=damage:
      		print("you killed it.")
      		print("luckily it was too slow to attack")
      	
      	elif enemie<=damage:
          	while enemie>=0 and life>=0:
          		
          		life = int(life) - 10
          		print("you hit the enemie")
          		print("it hit you")
          		print("your life:" , life)
          		enemie = int(enemie) - int(damage)
          		if enemie<=0:
          			print("you killed it.")
          		if life==0:
          			print("it killed you.")
          			print("Game over!")
          			room = 11
          	
    elif room==9:
      print("You found an exit!")
      print("Game Won!")
      room = int(input("restart? 1=yes 2=no"))
      if room==2:
          room = 11