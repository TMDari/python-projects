import os

path = '.'
files = [f for f in os.listdir(path) if os.path.isfile(f)]
for filename in files:
    print(filename)
File = input("Type exact file name to open")

exec(open(str(File)).read())