#python 3.7.1
import time
import math
import os
from PIL import Image
T = 1
Time = 1
Date = 1
chip = 1
inptmsg = "Select a number"


while chip==1:
  print ("-Chip OS-")
  time.sleep(T)
  print ("")
  print ("1.programms")
  print ("2.settings")
  time.sleep(T)
  print ("")
  if Time==1:
    print("Time: " + time.strftime("%H:%M"))
  if Date==1:
    print ("Date: " + time.strftime("%m/%d/%Y"))
  print ("")
  I = int(input(inptmsg))
  os.system('cls' if os.name == 'nt' else 'clear')
  
  
  if I==2:
    print("-Settings-")
    time.sleep(T)
    print("")
    print("1.text delay time")
    print("2.Date and Time")
    print("3.set input message")
    time.sleep(T)
    I = int(input(inptmsg))
    os.system('cls' if os.name == 'nt' else 'clear')
    
    if I==1:
      print("-text delay time-")
      print("")
      print("0=off above 3=very very slow")
      print("you can set it to any number")
      T = float(input(inptmsg))
      os.system('cls' if os.name == 'nt' else 'clear')
    
    elif I==2:
      print("Time 1=on 0=off")
      Time = int(input(inptmsg))
      print("Date 1=on 0=off")
      Date = int(input(inptmsg))
      os.system('cls' if os.name == 'nt' else 'clear')
    
    elif I==3:
      print("(anything)=on (nothing)=off")
      inptmsg = str(input("Type a message"))
      os.system('cls' if os.name == 'nt' else 'clear')
    else:
    	print("Error: Wrong input")
  
  elif I==1:
  	print("-Programms-")
  	print("")
  	print("1.Calculator")
  	print("2.Notes")
  	print("3.Files")
  	I = int(input(inptmsg))
  	os.system('cls' if os.name == 'nt' else 'clear')
  	
  	if I==1:
  		print("soon")
  		
  	elif I==2:
  		print("soon")
  		
  	elif I==3:
		  path = '.'
		  files = [f for f in os.listdir(path) if os.path.isfile(f)]
		  for filename in files:
	  	    print(filename)
		  File = input("Type exact file name to open")
		  os.system('cls' if os.name == 'nt' else 'clear')
		  if (File.__contains__(".png" or ".jpg")):
		  	img = Image.open(File)
		  	img.show()
		  	
		  else:
		  	exec(open(str(File)).read())
  	else:
  		print("Error: Wrong input")
  else:
  	print("Error: Wrong input")	  